
# this makes a list of pending_coding files, reads them in, and then opens them one by one
# moves relevant files to "old_relevant"

cd ../pending_coding
ls > notcoded
mv notcoded ../Code
cd ../Code

while IFS= read -r line;
do
  id=${line/.tmp/}
  echo "line is: " $id
  open -a "Firefox" ../pending_coding/"$line"
  read -p "More time? " ans </dev/tty
  read -p "Was it relevant? y/n " rev </dev/tty
  echo "relevant is: " $rev
  echo
  if [ "$rev" == "y" ]; then
      cp ../pending_coding/$line ../already_coded/old_relevant
      mv ../pending_coding/$line ../already_coded
  else
      mv ../pending_coding/$line ../already_coded
  fi
done < "notcoded"
